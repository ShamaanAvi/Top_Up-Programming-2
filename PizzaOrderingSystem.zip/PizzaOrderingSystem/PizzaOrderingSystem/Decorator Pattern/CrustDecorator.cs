﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Decorator_Pattern
{
    public class CrustDecorator(Pizza pizza, string crustName, decimal crustPrice) : PizzaDecorator(pizza)
    {
        private readonly string _crustName = crustName;
        private readonly decimal _crustPrice = crustPrice;

        public override string GetDescription() => $"{_pizza.GetDescription()}, {_crustName} Crust";
        public override decimal GetPrice() => _pizza.GetPrice() + _crustPrice;
    }
}
