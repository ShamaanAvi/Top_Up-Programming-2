﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Decorator_Pattern
{
    public class SauceDecorator(Pizza pizza, string sauceName, decimal saucePrice) : PizzaDecorator(pizza)
    {
        private readonly string _sauceName = sauceName;
        private readonly decimal _saucePrice = saucePrice;

        public override string GetDescription() => $"{_pizza.GetDescription()}, {_sauceName} Sauce";
        public override decimal GetPrice() => _pizza.GetPrice() + _saucePrice;
    }
}
