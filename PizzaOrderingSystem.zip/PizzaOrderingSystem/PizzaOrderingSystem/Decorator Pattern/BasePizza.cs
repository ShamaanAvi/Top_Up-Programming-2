﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Decorator_Pattern
{
    public class BasePizza : Pizza
    {
        public override string GetDescription() => "Base Pizza";
        public override decimal GetPrice() => 5.00m; // Starting base price
    }
}
