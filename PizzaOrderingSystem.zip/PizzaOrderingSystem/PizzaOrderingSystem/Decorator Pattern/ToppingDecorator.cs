﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Decorator_Pattern
{
    public class ToppingDecorator(Pizza pizza, string toppingName, decimal toppingPrice) : PizzaDecorator(pizza)
    {
        private readonly string _toppingName = toppingName;
        private readonly decimal _toppingPrice = toppingPrice;

        public override string GetDescription() => $"{_pizza.GetDescription()}, {_toppingName}";
        public override decimal GetPrice() => _pizza.GetPrice() + _toppingPrice;
    }
}
