﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Decorator_Pattern
{
    public class CheeseDecorator(Pizza pizza, string cheeseName, decimal cheesePrice) : PizzaDecorator(pizza)
    {
        private readonly string _cheeseName = cheeseName;
        private readonly decimal _cheesePrice = cheesePrice;

        public override string GetDescription() => $"{_pizza.GetDescription()}, {_cheeseName} Cheese";
        public override decimal GetPrice() => _pizza.GetPrice() + _cheesePrice;
    }
}
