﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Decorator_Pattern
{
    public abstract class PizzaDecorator(Pizza pizza) : Pizza
    {
        protected Pizza _pizza = pizza;

        public override string GetDescription() => _pizza.GetDescription();
        public override decimal GetPrice() => _pizza.GetPrice();
    }
}
