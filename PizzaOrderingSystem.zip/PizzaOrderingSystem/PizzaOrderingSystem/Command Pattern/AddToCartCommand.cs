﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PizzaOrderingSystem
{
    public class AddToCartCommand
    {
        private readonly int _userId;
        private readonly int? _pizzaId;
        private readonly int? _customPizzaId;
        private readonly decimal _price;
        private readonly int _quantity;

        public AddToCartCommand(int userId, int? pizzaId, int? customPizzaId, decimal price, int quantity)
        {
            _userId = userId;
            _pizzaId = pizzaId;
            _customPizzaId = customPizzaId;
            _price = price;
            _quantity = quantity;

            // Validation: Ensure only one of PizzaId or CustomPizzaId is provided
            if ((_pizzaId == null && _customPizzaId == null) || (_pizzaId != null && _customPizzaId != null))
            {
                throw new ArgumentException("Either PizzaId or CustomPizzaId must be provided, but not both.");
            }

            if (_quantity <= 0)
            {
                throw new ArgumentException("Quantity must be greater than zero.");
            }
        }

        public void Execute()
        {
            try
            {
                // Debug log before executing the INSERT
                Debug.WriteLine("===== Debugging AddToCartCommand =====");
                Debug.WriteLine($"UserId: {_userId}");
                Debug.WriteLine($"PizzaId: {_pizzaId}");
                Debug.WriteLine($"CustomPizzaId: {_customPizzaId}");
                Debug.WriteLine($"Quantity: {_quantity}");
                Debug.WriteLine($"Price: {_price}");

                // Additional validation for custom pizzas
                if (_customPizzaId != null && _customPizzaId <= 0)
                {
                    throw new ArgumentException("CustomPizzaId must be a valid positive integer when provided.");
                }

                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                string query = @"
                INSERT INTO ShoppingCart (UserId, PizzaId, CustomPizzaId, Quantity, Price)
                VALUES (@UserId, @PizzaId, @CustomPizzaId, @Quantity, @Price)";

                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", _userId);
                command.Parameters.AddWithValue("@PizzaId", (object)_pizzaId ?? DBNull.Value);
                command.Parameters.AddWithValue("@CustomPizzaId", (object)_customPizzaId ?? DBNull.Value);
                command.Parameters.AddWithValue("@Quantity", _quantity);
                command.Parameters.AddWithValue("@Price", _price);

                Debug.WriteLine("Executing SQL Command...");
                int rowsAffected = command.ExecuteNonQuery();
                Debug.WriteLine($"Rows Affected: {rowsAffected}");
            }
            catch (SqlException sqlEx)
            {
                // Log detailed SQL exception
                Debug.WriteLine("SQL Error: " + sqlEx.Message);
                MessageBox.Show("Database Error adding to cart: " + sqlEx.Message);
            }
            catch (Exception ex)
            {
                // Log general exceptions
                Debug.WriteLine("Error: " + ex.Message);
                MessageBox.Show("Error adding to cart: " + ex.Message);
            }
        }
    }
}
