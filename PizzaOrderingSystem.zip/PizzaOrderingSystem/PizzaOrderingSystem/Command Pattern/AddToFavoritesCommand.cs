﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PizzaOrderingSystem
{
    public class AddToFavoritesCommand
    {
        private readonly SqlConnection _connection;
        private readonly int? _customPizzaId;
        private readonly int? _pizzaId;

        public AddToFavoritesCommand(SqlConnection connection, int? customPizzaId = null, int? pizzaId = null)
        {
            _connection = connection;
            _customPizzaId = customPizzaId;
            _pizzaId = pizzaId;

            if (_customPizzaId == null && _pizzaId == null)
                throw new ArgumentException("Either Custom Pizza or Set pizza should be provided.");
        }

        public void Execute()
        {
            string query;
            SqlCommand command;

            if (_customPizzaId.HasValue)
            {
                // Query for custom pizzas
                query = @"
                INSERT INTO Favorites (UserId, CustomPizzaId, CreatedDate)
                SELECT 
                    UserId,
                    CustomPizzaId,
                    GETDATE()
                FROM CustomPizzas
                WHERE CustomPizzaId = @CustomPizzaId";

                command = new SqlCommand(query, _connection);
                command.Parameters.AddWithValue("@CustomPizzaId", _customPizzaId.Value);
            }
            else if (_pizzaId.HasValue)
            {
                // Query for predefined pizzas
                query = @"
                INSERT INTO Favorites (UserId, PizzaId, CreatedDate)
                VALUES (@UserId, @PizzaId, GETDATE())";

                command = new SqlCommand(query, _connection);
                command.Parameters.AddWithValue("@UserId", UserSession.UserId);
                command.Parameters.AddWithValue("@PizzaId", _pizzaId.Value);
            }
            else
            {
                throw new InvalidOperationException("Invalid state: no pizza ID provided.");
            }

            command.ExecuteNonQuery();
        }
    }
}
