﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.State_Pattern
{
    public class PreparingState : IOrderState
    {
        public void UpdateOrderStatus(OrderContext orderContext)
        {
            orderContext.SetState(new OutForDeliveryState());
            Console.WriteLine("Order moved from 'Preparing' to 'Out for Delivery'.");
        }

        public string GetState()
        {
            return "Preparing";
        }
    }
}
