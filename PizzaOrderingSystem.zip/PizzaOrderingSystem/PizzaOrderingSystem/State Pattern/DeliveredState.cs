﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.State_Pattern
{
    public class DeliveredState : IOrderState
    {
        public void UpdateOrderStatus(OrderContext orderContext)
        {
            Console.WriteLine("Order is already delivered. No further status updates.");
        }

        public string GetState()
        {
            return "Delivered";
        }
    }
}
