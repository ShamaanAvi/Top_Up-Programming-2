﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.State_Pattern
{
    public class OutForDeliveryState : IOrderState
    {
        public void UpdateOrderStatus(OrderContext orderContext)
        {
            orderContext.SetState(new DeliveredState());
            Console.WriteLine("Order moved from 'Out for Delivery' to 'Delivered'.");
        }

        public string GetState()
        {
            return "Out for Delivery";
        }
    }
}
