﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.State_Pattern
{
    public class PlacedState : IOrderState
    {
        public void UpdateOrderStatus(OrderContext orderContext)
        {
            orderContext.SetState(new PreparingState());
            Console.WriteLine("Order moved from 'Placed' to 'Preparing'.");
        }

        public string GetState()
        {
            return "Placed";
        }
    }
}
