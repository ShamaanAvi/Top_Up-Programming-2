﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using PizzaOrderingSystem.Strategy_Pattern;

namespace PizzaOrderingSystem
{
    public partial class fPayment : Form
    {
        public fPayment()
        {
            InitializeComponent();
            UpdateTotalPrice();
        }

        private void btnPlace_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbPay.SelectedItem == null)
                {
                    MessageBox.Show("Please select a payment method.", "Payment Method Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                bool isPickup = cbPay.SelectedItem.ToString() == "On Pickup";
                bool isDelivery = !isPickup;

                if (isDelivery && string.IsNullOrWhiteSpace(rbAdd.Text))
                {
                    MessageBox.Show("Please provide a delivery address.", "Address Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Determine the payment strategy
                IPaymentStrategy paymentStrategy = cbPay.SelectedItem.ToString() switch
                {
                    "On Pickup" => new OnPickupPayment(),
                    "Cash on Delivery" => new CashOnDeliveryPayment(),
                    "Card" => new CardPayment(),
                    "Loyalty Points" => new LoyaltyPointsPayment(UserSession.UserId),
                    _ => throw new InvalidOperationException("Unknown payment method.")
                };

                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                var orderBuilder = new OrderBuilder(connection);
                try
                {
                    orderBuilder
                        .StartTransaction()
                        .SetUserId(UserSession.UserId)
                        .SetDeliveryOption(isDelivery)
                        .SetDeliveryAddress(isDelivery ? rbAdd.Text : null)
                        .CalculateTotalPrice();

                    // Delegate payment processing to the selected strategy
                    paymentStrategy.ProcessPayment(orderBuilder);

                    orderBuilder
                        .InsertOrder()
                        .InsertOrderDetails()
                        .ClearShoppingCart()
                        .CommitTransaction();

                    //MessageBox.Show("Order placed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MessageBox.Show("Not enough loyalty points.", "Loyalty Points", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    ShowFeedbackPopup(orderBuilder.GetOrderId());
                    ResetForm();
                    LoadShoppingCart();
                }
                catch (Exception ex)
                {
                    orderBuilder.RollbackTransaction();
                    throw new Exception("Transaction failed: " + ex.Message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error placing order: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateTotalPrice()
        {
            try
            {
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                var orderBuilder = new OrderBuilder(connection);
                orderBuilder
                    .StartTransaction()
                    .SetUserId(UserSession.UserId)
                    .CalculateTotalPrice();

                lbTotal.Text = orderBuilder.TotalPrice.ToString("0.00");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error calculating total price: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private static void LoadShoppingCart()
        {
            try
            {
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                string query = @"
                SELECT 
                    CartItemId, 
                    CASE 
                        WHEN PizzaId IS NOT NULL THEN 'Regular Pizza'
                        WHEN CustomPizzaId IS NOT NULL THEN 'Custom Pizza'
                    END AS PizzaType,
                    Quantity,
                    Price
                FROM ShoppingCart
                WHERE UserId = @UserId";

                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", UserSession.UserId);

                using var adapter = new SqlDataAdapter(command);
                DataTable cartTable = new();
                adapter.Fill(cartTable);

                // Get the open instance of fMain

                if (Application.OpenForms["fMain"] is fMain mainForm)
                {
                    mainForm.dgCart.DataSource = cartTable;
                    mainForm.dgCart.Columns["CartItemId"].Visible = false;
                }
                else
                {
                    MessageBox.Show("Main form is not open.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading shopping cart: " + ex.Message);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void ResetForm()
        {
            cbPay.SelectedIndex = -1;
            tbCard.Clear();
            tbName.Clear();
            tbExp.Clear();
            tbCVV.Clear();
            rbAdd.Clear();
            lbCost.Text = "0.00";
            tbCard.Enabled = false;
            tbName.Enabled = false;
            tbExp.Enabled = false;
            tbCVV.Enabled = false;
            rbAdd.Enabled = false;
        }

        private void cbPay_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool isPickupOrLoyalty = cbPay.SelectedItem?.ToString() == "On Pickup" || cbPay.SelectedItem?.ToString() == "Loyalty Points";
            tbCard.Enabled = !isPickupOrLoyalty;
            tbName.Enabled = !isPickupOrLoyalty;
            tbExp.Enabled = !isPickupOrLoyalty;
            tbCVV.Enabled = !isPickupOrLoyalty;
            rbAdd.Enabled = !isPickupOrLoyalty;

        }

        private static void ShowFeedbackPopup(int orderId)
        {
            var feedbackForm = new fFeedback(orderId);
            feedbackForm.ShowDialog();
        }

        private void rbAdd_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
