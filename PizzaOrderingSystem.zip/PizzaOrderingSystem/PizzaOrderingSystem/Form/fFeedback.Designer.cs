﻿namespace PizzaOrderingSystem
{
    partial class fFeedback
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            btnBack = new Button();
            label1 = new Label();
            tbComments = new TextBox();
            btnRate5 = new Button();
            btnRate4 = new Button();
            btnRate3 = new Button();
            btnRate2 = new Button();
            btnRate1 = new Button();
            btnRate0 = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnBack);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(tbComments);
            groupBox1.Controls.Add(btnRate5);
            groupBox1.Controls.Add(btnRate4);
            groupBox1.Controls.Add(btnRate3);
            groupBox1.Controls.Add(btnRate2);
            groupBox1.Controls.Add(btnRate1);
            groupBox1.Controls.Add(btnRate0);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(776, 426);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            // 
            // btnBack
            // 
            btnBack.Location = new Point(658, 386);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(112, 34);
            btnBack.TabIndex = 8;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(274, 76);
            label1.Name = "label1";
            label1.Size = new Size(221, 25);
            label1.TabIndex = 7;
            label1.Text = "How was your experience?";
            // 
            // tbComments
            // 
            tbComments.Location = new Point(52, 133);
            tbComments.Name = "tbComments";
            tbComments.Size = new Size(666, 31);
            tbComments.TabIndex = 6;
            // 
            // btnRate5
            // 
            btnRate5.Location = new Point(521, 237);
            btnRate5.Name = "btnRate5";
            btnRate5.Size = new Size(35, 35);
            btnRate5.TabIndex = 5;
            btnRate5.Text = "5";
            btnRate5.UseVisualStyleBackColor = true;
            btnRate5.Click += btnRate_Click;
            // 
            // btnRate4
            // 
            btnRate4.Location = new Point(460, 237);
            btnRate4.Name = "btnRate4";
            btnRate4.Size = new Size(35, 35);
            btnRate4.TabIndex = 4;
            btnRate4.Text = "4";
            btnRate4.UseVisualStyleBackColor = true;
            btnRate4.Click += btnRate_Click;
            // 
            // btnRate3
            // 
            btnRate3.Location = new Point(399, 237);
            btnRate3.Name = "btnRate3";
            btnRate3.Size = new Size(35, 35);
            btnRate3.TabIndex = 3;
            btnRate3.Text = "3";
            btnRate3.UseVisualStyleBackColor = true;
            btnRate3.Click += btnRate_Click;
            // 
            // btnRate2
            // 
            btnRate2.Location = new Point(338, 237);
            btnRate2.Name = "btnRate2";
            btnRate2.Size = new Size(35, 35);
            btnRate2.TabIndex = 2;
            btnRate2.Text = "2";
            btnRate2.UseVisualStyleBackColor = true;
            btnRate2.Click += btnRate_Click;
            // 
            // btnRate1
            // 
            btnRate1.Location = new Point(277, 237);
            btnRate1.Name = "btnRate1";
            btnRate1.Size = new Size(35, 35);
            btnRate1.TabIndex = 1;
            btnRate1.Text = "1";
            btnRate1.UseVisualStyleBackColor = true;
            btnRate1.Click += btnRate_Click;
            // 
            // btnRate0
            // 
            btnRate0.Location = new Point(216, 237);
            btnRate0.Name = "btnRate0";
            btnRate0.Size = new Size(35, 35);
            btnRate0.TabIndex = 0;
            btnRate0.Text = "0";
            btnRate0.UseVisualStyleBackColor = true;
            btnRate0.Click += btnRate_Click;
            // 
            // fFeedback
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Name = "fFeedback";
            Text = "Rating and Review";
            Load += fFeedback_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button btnRate0;
        private TextBox tbComments;
        private Button btnRate5;
        private Button btnRate4;
        private Button btnRate3;
        private Button btnRate2;
        private Button btnRate1;
        private Label label1;
        private Button btnBack;
    }
}