﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace PizzaOrderingSystem
{
    public partial class fFeedback : Form
    {
        private readonly int _orderId;
        public fFeedback(int orderId)
        {
            InitializeComponent();
            _orderId = orderId;
        }

        private void RateOrder(int rating)
        {
            try
            {
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                string query = @"
                INSERT INTO Feedback (OrderId, Rating, Comments)
                VALUES (@OrderId, @Rating, @Comments)";

                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@OrderId", _orderId);
                command.Parameters.AddWithValue("@Rating", rating);
                command.Parameters.AddWithValue("@Comments", tbComments.Text);

                command.ExecuteNonQuery();
                MessageBox.Show("Thank you for your feedback!", "Feedback Submitted", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error submitting feedback: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRate_Click(object sender, EventArgs e)
        {
            if (sender is Button button && int.TryParse(button.Text, out int rating))
            {
                RateOrder(rating);
            }
        }

        private void fFeedback_Load(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {

        }
    }
}
