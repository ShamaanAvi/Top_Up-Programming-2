using Microsoft.Data.SqlClient;

namespace PizzaOrderingSystem
{
    public partial class fUser : Form
    {
        public fUser()
        {
            InitializeComponent();
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            string username = txtUser.Text.Trim();
            string password = txtPass.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both username and password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                // Check credentials
                string query = "SELECT UserId, Email FROM Users WHERE Username = @Username AND Password = @Password";
                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", password);

                using var reader = command.ExecuteReader();

                if (reader.Read())
                {
                    // Store user details in UserSession
                    UserSession.UserId = reader.GetInt32(0); // UserId column
                    UserSession.Username = username; // Username
                    UserSession.Email = reader.GetString(1); // Email column

                    // Open the Main Menu form
                    fMain mainForm = new();
                    mainForm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while trying to log in. Please try again later.\n\nError Details: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    
}
