﻿namespace PizzaOrderingSystem
{
    partial class fPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnPlace = new Button();
            groupBox1 = new GroupBox();
            lbTotal = new Label();
            lbCost = new Label();
            label7 = new Label();
            cbPay = new ComboBox();
            rbAdd = new RichTextBox();
            tbCVV = new TextBox();
            tbExp = new TextBox();
            tbName = new TextBox();
            tbCard = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // btnPlace
            // 
            btnPlace.Location = new Point(731, 530);
            btnPlace.Name = "btnPlace";
            btnPlace.Size = new Size(117, 34);
            btnPlace.TabIndex = 7;
            btnPlace.Text = "Place Order";
            btnPlace.UseVisualStyleBackColor = true;
            btnPlace.Click += btnPlace_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lbTotal);
            groupBox1.Controls.Add(lbCost);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(cbPay);
            groupBox1.Controls.Add(rbAdd);
            groupBox1.Controls.Add(tbCVV);
            groupBox1.Controls.Add(tbExp);
            groupBox1.Controls.Add(tbName);
            groupBox1.Controls.Add(tbCard);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(btnPlace);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(854, 570);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Text = "Order and Payment Details";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // lbTotal
            // 
            lbTotal.AutoSize = true;
            lbTotal.Location = new Point(758, 481);
            lbTotal.Name = "lbTotal";
            lbTotal.Size = new Size(16, 25);
            lbTotal.TabIndex = 22;
            lbTotal.Text = ".";
            // 
            // lbCost
            // 
            lbCost.AutoSize = true;
            lbCost.Location = new Point(758, 481);
            lbCost.Name = "lbCost";
            lbCost.Size = new Size(0, 25);
            lbCost.TabIndex = 21;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(758, 447);
            label7.Name = "label7";
            label7.Size = new Size(90, 25);
            label7.TabIndex = 20;
            label7.Text = "Total Cost";
            // 
            // cbPay
            // 
            cbPay.FormattingEnabled = true;
            cbPay.Items.AddRange(new object[] { "On Pickup", "Cash on Delivery", "Card", "Loyalty Points" });
            cbPay.Location = new Point(263, 69);
            cbPay.Name = "cbPay";
            cbPay.Size = new Size(196, 33);
            cbPay.TabIndex = 19;
            cbPay.SelectedIndexChanged += cbPay_SelectedIndexChanged;
            // 
            // rbAdd
            // 
            rbAdd.Location = new Point(263, 360);
            rbAdd.Name = "rbAdd";
            rbAdd.Size = new Size(270, 125);
            rbAdd.TabIndex = 18;
            rbAdd.Text = "";
            rbAdd.TextChanged += rbAdd_TextChanged;
            // 
            // tbCVV
            // 
            tbCVV.Location = new Point(263, 313);
            tbCVV.Name = "tbCVV";
            tbCVV.Size = new Size(65, 31);
            tbCVV.TabIndex = 17;
            // 
            // tbExp
            // 
            tbExp.Location = new Point(263, 252);
            tbExp.Name = "tbExp";
            tbExp.Size = new Size(65, 31);
            tbExp.TabIndex = 16;
            // 
            // tbName
            // 
            tbName.Location = new Point(263, 191);
            tbName.Name = "tbName";
            tbName.Size = new Size(270, 31);
            tbName.TabIndex = 15;
            // 
            // tbCard
            // 
            tbCard.Location = new Point(263, 127);
            tbCard.Name = "tbCard";
            tbCard.Size = new Size(270, 31);
            tbCard.TabIndex = 14;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 377);
            label6.Name = "label6";
            label6.Size = new Size(145, 25);
            label6.TabIndex = 13;
            label6.Text = "Delivery Address";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 316);
            label5.Name = "label5";
            label5.Size = new Size(45, 25);
            label5.TabIndex = 12;
            label5.Text = "CVV";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 255);
            label4.Name = "label4";
            label4.Size = new Size(101, 25);
            label4.TabIndex = 11;
            label4.Text = "Expiry Date";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 194);
            label3.Name = "label3";
            label3.Size = new Size(127, 25);
            label3.TabIndex = 10;
            label3.Text = "Name on Card";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 133);
            label2.Name = "label2";
            label2.Size = new Size(82, 25);
            label2.TabIndex = 9;
            label2.Text = "Card No.";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 72);
            label1.Name = "label1";
            label1.Size = new Size(148, 25);
            label1.TabIndex = 8;
            label1.Text = "Payment Method";
            // 
            // fPayment
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(878, 594);
            Controls.Add(groupBox1);
            Name = "fPayment";
            Text = "Payment";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btnPlace;
        private GroupBox groupBox1;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private ComboBox cbPay;
        private RichTextBox rbAdd;
        private TextBox tbCVV;
        private TextBox tbExp;
        private TextBox tbName;
        private TextBox tbCard;
        private Label lbCost;
        private Label label7;
        private Label lbTotal;
    }
}