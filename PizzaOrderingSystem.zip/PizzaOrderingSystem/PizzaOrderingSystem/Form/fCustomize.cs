﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using PizzaOrderingSystem.Chain_of_Responsibility_Pattern;
using PizzaOrderingSystem.Decorator_Pattern;

namespace PizzaOrderingSystem
{
    public partial class fCustomize : Form
    {
        public fCustomize()
        {
            InitializeComponent();
            LoadComboBoxData();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnCart_Click(object sender, EventArgs e)
        {
            try
            {
                // Set up the chain of responsibility for validation
                var crustValidator = new CrustValidator();
                var sauceValidator = new SauceValidator();
                var cheeseValidator = new CheeseValidator();
                var toppingValidator = new ToppingValidator();

                crustValidator.SetNext(sauceValidator)
                              .SetNext(cheeseValidator)
                              .SetNext(toppingValidator);

                // Create a context object for validation
                var context = new ValidationContext
                {
                    Crust = cbCrust.SelectedItem as ComboBoxItem,
                    Sauce = cbSauce.SelectedItem as ComboBoxItem,
                    Cheese = cbCheese.SelectedItem as ComboBoxItem,
                    Topping1 = cbTop1.SelectedItem as ComboBoxItem,
                    Topping2 = cbTop2.SelectedItem as ComboBoxItem
                };

                // Perform validation
                crustValidator.Validate(context);

                // Create the base pizza and decorate it with the selected items
                Pizza customPizza = new BasePizza();

                if (context.Crust != null)
                {
                    customPizza = new CrustDecorator(customPizza, context.Crust.Text, context.Crust.Price);
                }

                if (context.Sauce != null)
                {
                    customPizza = new SauceDecorator(customPizza, context.Sauce.Text, context.Sauce.Price);
                }

                if (context.Cheese != null)
                {
                    customPizza = new CheeseDecorator(customPizza, context.Cheese.Text, context.Cheese.Price);
                }

                if (context.Topping1 != null)
                {
                    customPizza = new ToppingDecorator(customPizza, context.Topping1.Text, context.Topping1.Price);
                }

                if (context.Topping2 != null)
                {
                    customPizza = new ToppingDecorator(customPizza, context.Topping2.Text, context.Topping2.Price);
                }

                decimal finalPrice = customPizza.GetPrice();

                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                // Insert Custom Pizza with Name
                var insertPizzaQuery = @"
                INSERT INTO CustomPizzas (UserId, Name, CrustTypeId, SauceTypeId, CheeseTypeId, BasePrice) 
                OUTPUT INSERTED.CustomPizzaId
                VALUES (@UserId, @Name, @CrustTypeId, @SauceTypeId, @CheeseTypeId, @BasePrice)";

                int customPizzaId;
                using (var command = new SqlCommand(insertPizzaQuery, connection))
                {
                    command.Parameters.AddWithValue("@UserId", UserSession.UserId);
                    command.Parameters.AddWithValue("@Name", txtCusName.Text.Trim());
                    command.Parameters.AddWithValue("@CrustTypeId", context.Crust?.Value ?? throw new Exception("Crust type is required."));
                    command.Parameters.AddWithValue("@SauceTypeId", context.Sauce?.Value ?? throw new Exception("Sauce type is required."));
                    command.Parameters.AddWithValue("@CheeseTypeId", context.Cheese?.Value ?? throw new Exception("Cheese type is required."));
                    command.Parameters.AddWithValue("@BasePrice", finalPrice);

                    customPizzaId = (int)command.ExecuteScalar();
                }

                if (customPizzaId <= 0)
                    throw new Exception("Failed to create custom pizza. Please try again.");

                // Add Toppings
                AddToppings(connection, customPizzaId, context);

                // Add to Cart
                var addToCartCommand = new AddToCartCommand(UserSession.UserId, null, customPizzaId, finalPrice, 1);
                addToCartCommand.Execute();

                // Show dialog for adding to favorites
                ShowAddToFavoritesDialog(connection, customPizzaId);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private static void AddToppings(SqlConnection connection, int customPizzaId, ValidationContext context)
        {
            var toppingsQuery = @"
        INSERT INTO PizzaToppings (CustomPizzaId, ToppingId) 
        VALUES (@CustomPizzaId, @ToppingId)";

            using var command = new SqlCommand(toppingsQuery, connection);
            command.Parameters.AddWithValue("@CustomPizzaId", customPizzaId);

            if (context.Topping1 != null)
            {
                command.Parameters.AddWithValue("@ToppingId", context.Topping1.Value);
                command.ExecuteNonQuery();
            }

            if (context.Topping2 != null)
            {
                command.Parameters["@ToppingId"].Value = context.Topping2.Value;
                command.ExecuteNonQuery();
            }
        }

        private static void ShowAddToFavoritesDialog(SqlConnection connection, int customPizzaId)
        {
            var dialogResult = MessageBox.Show(
                "Like this combo? Add to favorites?",
                "Add to Favorites",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (dialogResult == DialogResult.Yes)
            {
                AddToFavoritesCommand addToFavorites = new(connection, customPizzaId);
                addToFavorites.Execute();
                MessageBox.Show("Custom pizza added to favorites!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void LoadComboBoxData()
        {
            using var connection = new SqlConnection(dbConn.ConnectionString);
            connection.Open();

            // Load Crust Types
            var crustQuery = "SELECT CrustTypeId, Name FROM CrustTypes";
            using (var crustCommand = new SqlCommand(crustQuery, connection))
            using (var reader = crustCommand.ExecuteReader())
            {
                while (reader.Read())
                {
                    cbCrust.Items.Add(new ComboBoxItem { Text = reader["Name"].ToString(), Value = reader["CrustTypeId"] });
                }
            }

            // Load Sauce Types
            var sauceQuery = "SELECT SauceTypeId, Name FROM SauceTypes";
            using (var sauceCommand = new SqlCommand(sauceQuery, connection))
            using (var reader = sauceCommand.ExecuteReader())
            {
                while (reader.Read())
                {
                    cbSauce.Items.Add(new ComboBoxItem { Text = reader["Name"].ToString(), Value = reader["SauceTypeId"] });
                }
            }

            // Load Cheese Types
            var cheeseQuery = "SELECT CheeseTypeId, Name FROM CheeseTypes";
            using (var cheeseCommand = new SqlCommand(cheeseQuery, connection))
            using (var reader = cheeseCommand.ExecuteReader())
            {
                while (reader.Read())
                {
                    cbCheese.Items.Add(new ComboBoxItem { Text = reader["Name"].ToString(), Value = reader["CheeseTypeId"] });
                }
            }

            // Load Toppings
            var toppingsQuery = "SELECT ToppingId, Name FROM Toppings";
            using (var toppingsCommand = new SqlCommand(toppingsQuery, connection))
            using (var reader = toppingsCommand.ExecuteReader())
            {
                while (reader.Read())
                {
                    var item = new ComboBoxItem { Text = reader["Name"].ToString(), Value = reader["ToppingId"] };
                    cbTop1.Items.Add(item);
                    cbTop2.Items.Add(item);
                }
            }
        }

        private void cbTop1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTop1.SelectedItem != null && cbTop1.SelectedItem == cbTop2.SelectedItem)
            {
                MessageBox.Show("Please select a different topping for the second topping.");
                cbTop1.SelectedIndex = -1; // Clear the selection
            }
        }

        private void cbTop2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbTop2.SelectedItem != null && cbTop2.SelectedItem == cbTop1.SelectedItem)
            {
                MessageBox.Show("Please select a different topping for the first topping.");
                cbTop2.SelectedIndex = -1; // Clear the selection
            }
        }
    }
    
}
