﻿namespace PizzaOrderingSystem
{
    partial class fMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pbProm1 = new PictureBox();
            dgProm = new DataGridView();
            tcMain = new TabControl();
            tcHome = new TabPage();
            groupBox2 = new GroupBox();
            btnOrder = new Button();
            tcOrder = new TabPage();
            btnCus = new Button();
            groupBox1 = new GroupBox();
            btnAdd = new Button();
            btnFav = new Button();
            btnCust = new Button();
            pbProm2 = new PictureBox();
            dgPizza = new DataGridView();
            tcCart = new TabPage();
            btnRem = new Button();
            btnPlace = new Button();
            dgCart = new DataGridView();
            tcFavorite = new TabPage();
            btnRem1 = new Button();
            btnCart1 = new Button();
            dgFav = new DataGridView();
            tcHistory = new TabPage();
            groupBox3 = new GroupBox();
            dgOn = new DataGridView();
            btnCart2 = new Button();
            dgHis = new DataGridView();
            tcProfile = new TabPage();
            lblLoyaltyPoints = new Label();
            btnBack = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pbProm1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgProm).BeginInit();
            tcMain.SuspendLayout();
            tcHome.SuspendLayout();
            groupBox2.SuspendLayout();
            tcOrder.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbProm2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgPizza).BeginInit();
            tcCart.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgCart).BeginInit();
            tcFavorite.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgFav).BeginInit();
            tcHistory.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgOn).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgHis).BeginInit();
            tcProfile.SuspendLayout();
            SuspendLayout();
            // 
            // pbProm1
            // 
            pbProm1.Location = new Point(6, 6);
            pbProm1.Name = "pbProm1";
            pbProm1.Size = new Size(855, 186);
            pbProm1.SizeMode = PictureBoxSizeMode.CenterImage;
            pbProm1.TabIndex = 0;
            pbProm1.TabStop = false;
            // 
            // dgProm
            // 
            dgProm.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgProm.Location = new Point(227, 30);
            dgProm.Name = "dgProm";
            dgProm.RowHeadersWidth = 62;
            dgProm.Size = new Size(379, 238);
            dgProm.TabIndex = 1;
            // 
            // tcMain
            // 
            tcMain.Controls.Add(tcHome);
            tcMain.Controls.Add(tcOrder);
            tcMain.Controls.Add(tcCart);
            tcMain.Controls.Add(tcFavorite);
            tcMain.Controls.Add(tcHistory);
            tcMain.Controls.Add(tcProfile);
            tcMain.Location = new Point(12, 12);
            tcMain.Name = "tcMain";
            tcMain.SelectedIndex = 0;
            tcMain.Size = new Size(875, 523);
            tcMain.SizeMode = TabSizeMode.Fixed;
            tcMain.TabIndex = 5;
            tcMain.SelectedIndexChanged += tcMain_SelectedIndexChanged;
            // 
            // tcHome
            // 
            tcHome.Controls.Add(groupBox2);
            tcHome.Controls.Add(pbProm1);
            tcHome.Location = new Point(4, 34);
            tcHome.Name = "tcHome";
            tcHome.Padding = new Padding(3);
            tcHome.Size = new Size(867, 485);
            tcHome.TabIndex = 0;
            tcHome.Text = "Home";
            tcHome.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnOrder);
            groupBox2.Controls.Add(dgProm);
            groupBox2.Location = new Point(6, 190);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(855, 286);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Enter += groupBox2_Enter;
            // 
            // btnOrder
            // 
            btnOrder.Location = new Point(736, 246);
            btnOrder.Name = "btnOrder";
            btnOrder.Size = new Size(113, 34);
            btnOrder.TabIndex = 2;
            btnOrder.Text = "Order Now!";
            btnOrder.UseVisualStyleBackColor = true;
            btnOrder.Click += btnOrder_Click;
            // 
            // tcOrder
            // 
            tcOrder.Controls.Add(btnCus);
            tcOrder.Controls.Add(groupBox1);
            tcOrder.Location = new Point(4, 34);
            tcOrder.Name = "tcOrder";
            tcOrder.Padding = new Padding(3);
            tcOrder.Size = new Size(867, 485);
            tcOrder.TabIndex = 1;
            tcOrder.Text = "Order";
            tcOrder.UseVisualStyleBackColor = true;
            // 
            // btnCus
            // 
            btnCus.Location = new Point(728, 492);
            btnCus.Name = "btnCus";
            btnCus.Size = new Size(112, 34);
            btnCus.TabIndex = 4;
            btnCus.Text = "Customize";
            btnCus.UseVisualStyleBackColor = true;
            btnCus.Click += btnCus_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnAdd);
            groupBox1.Controls.Add(btnFav);
            groupBox1.Controls.Add(btnCust);
            groupBox1.Controls.Add(pbProm2);
            groupBox1.Controls.Add(dgPizza);
            groupBox1.Location = new Point(6, 6);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(855, 462);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(463, 407);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(115, 34);
            btnAdd.TabIndex = 6;
            btnAdd.Text = "Add to Cart";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnFav
            // 
            btnFav.Location = new Point(584, 407);
            btnFav.Name = "btnFav";
            btnFav.Size = new Size(151, 34);
            btnFav.TabIndex = 5;
            btnFav.Text = "Add to Favorites";
            btnFav.UseVisualStyleBackColor = true;
            btnFav.Click += btnFav_Click_1;
            // 
            // btnCust
            // 
            btnCust.Location = new Point(741, 407);
            btnCust.Name = "btnCust";
            btnCust.Size = new Size(114, 34);
            btnCust.TabIndex = 4;
            btnCust.Text = "Customize";
            btnCust.UseVisualStyleBackColor = true;
            btnCust.Click += btnCust_Click;
            // 
            // pbProm2
            // 
            pbProm2.Location = new Point(0, 0);
            pbProm2.Name = "pbProm2";
            pbProm2.Size = new Size(849, 191);
            pbProm2.TabIndex = 1;
            pbProm2.TabStop = false;
            // 
            // dgPizza
            // 
            dgPizza.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgPizza.Location = new Point(6, 197);
            dgPizza.Name = "dgPizza";
            dgPizza.RowHeadersWidth = 62;
            dgPizza.Size = new Size(843, 204);
            dgPizza.TabIndex = 2;
            // 
            // tcCart
            // 
            tcCart.Controls.Add(btnRem);
            tcCart.Controls.Add(btnPlace);
            tcCart.Controls.Add(dgCart);
            tcCart.Location = new Point(4, 34);
            tcCart.Name = "tcCart";
            tcCart.Size = new Size(867, 485);
            tcCart.TabIndex = 5;
            tcCart.Text = "Cart";
            tcCart.UseVisualStyleBackColor = true;
            tcCart.Click += tcCart_Click;
            // 
            // btnRem
            // 
            btnRem.Location = new Point(624, 418);
            btnRem.Name = "btnRem";
            btnRem.Size = new Size(117, 34);
            btnRem.TabIndex = 7;
            btnRem.Text = "Remove";
            btnRem.UseVisualStyleBackColor = true;
            btnRem.Click += button1_Click;
            // 
            // btnPlace
            // 
            btnPlace.Location = new Point(747, 418);
            btnPlace.Name = "btnPlace";
            btnPlace.Size = new Size(117, 34);
            btnPlace.TabIndex = 6;
            btnPlace.Text = "Place Order";
            btnPlace.UseVisualStyleBackColor = true;
            btnPlace.Click += btnPlace_Click;
            // 
            // dgCart
            // 
            dgCart.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgCart.Location = new Point(3, 3);
            dgCart.Name = "dgCart";
            dgCart.RowHeadersWidth = 62;
            dgCart.Size = new Size(861, 396);
            dgCart.TabIndex = 3;
            // 
            // tcFavorite
            // 
            tcFavorite.Controls.Add(btnRem1);
            tcFavorite.Controls.Add(btnCart1);
            tcFavorite.Controls.Add(dgFav);
            tcFavorite.Location = new Point(4, 34);
            tcFavorite.Name = "tcFavorite";
            tcFavorite.Size = new Size(867, 485);
            tcFavorite.TabIndex = 4;
            tcFavorite.Text = "Favorites";
            tcFavorite.UseVisualStyleBackColor = true;
            // 
            // btnRem1
            // 
            btnRem1.Location = new Point(624, 418);
            btnRem1.Name = "btnRem1";
            btnRem1.Size = new Size(117, 34);
            btnRem1.TabIndex = 9;
            btnRem1.Text = "Remove";
            btnRem1.UseVisualStyleBackColor = true;
            btnRem1.Click += btnRem1_Click;
            // 
            // btnCart1
            // 
            btnCart1.Location = new Point(747, 418);
            btnCart1.Name = "btnCart1";
            btnCart1.Size = new Size(117, 34);
            btnCart1.TabIndex = 8;
            btnCart1.Text = "Re-order";
            btnCart1.UseVisualStyleBackColor = true;
            btnCart1.Click += btnCart1_Click;
            // 
            // dgFav
            // 
            dgFav.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgFav.Location = new Point(3, 3);
            dgFav.Name = "dgFav";
            dgFav.RowHeadersWidth = 62;
            dgFav.Size = new Size(861, 396);
            dgFav.TabIndex = 4;
            // 
            // tcHistory
            // 
            tcHistory.Controls.Add(groupBox3);
            tcHistory.Controls.Add(btnCart2);
            tcHistory.Controls.Add(dgHis);
            tcHistory.Location = new Point(4, 34);
            tcHistory.Name = "tcHistory";
            tcHistory.Size = new Size(867, 485);
            tcHistory.TabIndex = 3;
            tcHistory.Text = "History";
            tcHistory.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(dgOn);
            groupBox3.Location = new Point(3, 306);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(861, 176);
            groupBox3.TabIndex = 12;
            groupBox3.TabStop = false;
            groupBox3.Text = "Ongoing";
            // 
            // dgOn
            // 
            dgOn.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgOn.Location = new Point(6, 30);
            dgOn.Name = "dgOn";
            dgOn.RowHeadersWidth = 62;
            dgOn.Size = new Size(849, 140);
            dgOn.TabIndex = 11;
            // 
            // btnCart2
            // 
            btnCart2.Location = new Point(0, 0);
            btnCart2.Name = "btnCart2";
            btnCart2.Size = new Size(75, 23);
            btnCart2.TabIndex = 13;
            // 
            // dgHis
            // 
            dgHis.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgHis.Location = new Point(3, 3);
            dgHis.Name = "dgHis";
            dgHis.RowHeadersWidth = 62;
            dgHis.Size = new Size(861, 245);
            dgHis.TabIndex = 9;
            // 
            // tcProfile
            // 
            tcProfile.Controls.Add(label1);
            tcProfile.Controls.Add(lblLoyaltyPoints);
            tcProfile.Location = new Point(4, 34);
            tcProfile.Name = "tcProfile";
            tcProfile.Size = new Size(867, 485);
            tcProfile.TabIndex = 2;
            tcProfile.Text = "Profile";
            tcProfile.UseVisualStyleBackColor = true;
            // 
            // lblLoyaltyPoints
            // 
            lblLoyaltyPoints.AutoSize = true;
            lblLoyaltyPoints.Location = new Point(817, 443);
            lblLoyaltyPoints.Name = "lblLoyaltyPoints";
            lblLoyaltyPoints.Size = new Size(32, 25);
            lblLoyaltyPoints.TabIndex = 0;
            lblLoyaltyPoints.Text = ".....";
            // 
            // btnBack
            // 
            btnBack.Location = new Point(775, 541);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(112, 34);
            btnBack.TabIndex = 3;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(34, 42);
            label1.Name = "label1";
            label1.Size = new Size(32, 25);
            label1.TabIndex = 1;
            label1.Text = ".....";
            // 
            // fMain
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(899, 587);
            Controls.Add(btnBack);
            Controls.Add(tcMain);
            Name = "fMain";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Main Menu";
            ((System.ComponentModel.ISupportInitialize)pbProm1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgProm).EndInit();
            tcMain.ResumeLayout(false);
            tcHome.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            tcOrder.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pbProm2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgPizza).EndInit();
            tcCart.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgCart).EndInit();
            tcFavorite.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgFav).EndInit();
            tcHistory.ResumeLayout(false);
            groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgOn).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgHis).EndInit();
            tcProfile.ResumeLayout(false);
            tcProfile.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pbProm1;
        private DataGridView dgProm;
        private TabControl tcMain;
        private TabPage tcHome;
        private TabPage tcOrder;
        private TabPage tcProfile;
        private TabPage tcHistory;
        private TabPage tcFavorite;
        private Button btnOrder;
        private PictureBox pbProm2;
        private DataGridView dgPizza;
        private GroupBox groupBox1;
        private Button btnCus;
        private Button btnBack;
        private GroupBox groupBox2;
        private Button btnFav;
        private Button btnCust;
        private Button btnAdd;
        private TabPage tcCart;
        private Button btnPlace;
        private Button btnRem;
        public DataGridView dgCart;
        private Label lblLoyaltyPoints;
        private Button btnRem1;
        private Button btnCart1;
        public DataGridView dgFav;
        private Button btnCart2;
        public DataGridView dgHis;
        private GroupBox groupBox3;
        public DataGridView dgOn;
        private Label label1;
    }
}