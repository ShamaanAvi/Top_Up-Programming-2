﻿namespace PizzaOrderingSystem
{
    partial class fCustomize
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCart = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            cbCrust = new ComboBox();
            cbSauce = new ComboBox();
            cbCheese = new ComboBox();
            txtCusName = new TextBox();
            label5 = new Label();
            label6 = new Label();
            cbTop1 = new ComboBox();
            cbTop2 = new ComboBox();
            groupBox1 = new GroupBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // btnCart
            // 
            btnCart.Location = new Point(734, 470);
            btnCart.Name = "btnCart";
            btnCart.Size = new Size(114, 34);
            btnCart.TabIndex = 4;
            btnCart.Text = "Add to Cart";
            btnCart.UseVisualStyleBackColor = true;
            btnCart.Click += btnCart_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 62);
            label1.Name = "label1";
            label1.Size = new Size(210, 25);
            label1.TabIndex = 5;
            label1.Text = "Custom Name (Optional)";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 134);
            label2.Name = "label2";
            label2.Size = new Size(95, 25);
            label2.TabIndex = 6;
            label2.Text = "Crust Type";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 206);
            label3.Name = "label3";
            label3.Size = new Size(100, 25);
            label3.TabIndex = 7;
            label3.Text = "Sauce Type";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 278);
            label4.Name = "label4";
            label4.Size = new Size(110, 25);
            label4.TabIndex = 8;
            label4.Text = "Cheese Type";
            // 
            // cbCrust
            // 
            cbCrust.FormattingEnabled = true;
            cbCrust.Location = new Point(239, 131);
            cbCrust.Name = "cbCrust";
            cbCrust.Size = new Size(255, 33);
            cbCrust.TabIndex = 9;
            // 
            // cbSauce
            // 
            cbSauce.FormattingEnabled = true;
            cbSauce.Location = new Point(239, 203);
            cbSauce.Name = "cbSauce";
            cbSauce.Size = new Size(255, 33);
            cbSauce.TabIndex = 10;
            // 
            // cbCheese
            // 
            cbCheese.FormattingEnabled = true;
            cbCheese.Location = new Point(239, 275);
            cbCheese.Name = "cbCheese";
            cbCheese.Size = new Size(255, 33);
            cbCheese.TabIndex = 11;
            // 
            // txtCusName
            // 
            txtCusName.Location = new Point(239, 62);
            txtCusName.Name = "txtCusName";
            txtCusName.Size = new Size(255, 31);
            txtCusName.TabIndex = 12;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 350);
            label5.Name = "label5";
            label5.Size = new Size(92, 25);
            label5.TabIndex = 13;
            label5.Text = "Topping 1";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 422);
            label6.Name = "label6";
            label6.Size = new Size(92, 25);
            label6.TabIndex = 14;
            label6.Text = "Topping 2";
            // 
            // cbTop1
            // 
            cbTop1.FormattingEnabled = true;
            cbTop1.Location = new Point(239, 347);
            cbTop1.Name = "cbTop1";
            cbTop1.Size = new Size(255, 33);
            cbTop1.TabIndex = 15;
            cbTop1.SelectedIndexChanged += cbTop1_SelectedIndexChanged;
            // 
            // cbTop2
            // 
            cbTop2.FormattingEnabled = true;
            cbTop2.Location = new Point(239, 419);
            cbTop2.Name = "cbTop2";
            cbTop2.Size = new Size(255, 33);
            cbTop2.TabIndex = 16;
            cbTop2.SelectedIndexChanged += cbTop2_SelectedIndexChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(cbTop2);
            groupBox1.Controls.Add(cbTop1);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(txtCusName);
            groupBox1.Controls.Add(cbCheese);
            groupBox1.Controls.Add(cbSauce);
            groupBox1.Controls.Add(cbCrust);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(btnCart);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(854, 510);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            groupBox1.Text = "Create Pizza";
            // 
            // fCustomize
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(878, 594);
            Controls.Add(groupBox1);
            Name = "fCustomize";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Pizza Customization";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btnCart;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private ComboBox cbCrust;
        private ComboBox cbSauce;
        private ComboBox cbCheese;
        private TextBox txtCusName;
        private Label label5;
        private Label label6;
        private ComboBox cbTop1;
        private ComboBox cbTop2;
        private GroupBox groupBox1;
    }
}