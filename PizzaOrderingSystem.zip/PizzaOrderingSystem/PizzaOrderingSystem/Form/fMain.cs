﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using PizzaOrderingSystem.State_Pattern;

namespace PizzaOrderingSystem
{
    public partial class fMain : Form
    {
        private readonly List<string> promoImages = [];
        private int currentImageIndex = 0;
        private readonly System.Windows.Forms.Timer timerProm = new();

        public fMain()
        {
            InitializeComponent();
            LoadPromotions();
            SetupTimerForPromotions(pbProm1);
            SetupTimerForPromotions(pbProm2);
            LoadPizzas();
            LoadFavorites();
            LoadUserLoyaltyPoints();
            //InitializeOrderTrackingTimer();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            tcMain.SelectedTab = tcOrder;
        }

        private void btnCus_Click(object sender, EventArgs e)
        {
            fCustomize customizeForm = new();
            customizeForm.Show();
            this.Hide();
        }

        private void LoadPromotions()
        {
            try
            {
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                string query = "SELECT ImagePath, Name, Description FROM Promotions WHERE StartDate <= GETDATE() AND EndDate >= GETDATE()";
                using var command = new SqlCommand(query, connection);
                using var reader = command.ExecuteReader();

                DataTable promoTable = new();
                promoTable.Load(reader);

                dgProm.DataSource = promoTable;

                if (dgProm.Columns.Contains("ImagePath"))
                {
                    dgProm.Columns["ImagePath"].Visible = false;
                }

                foreach (DataRow row in promoTable.Rows)
                {
                    string imagePath = row["ImagePath"]?.ToString();
                    if (!string.IsNullOrEmpty(imagePath))
                    {
                        promoImages.Add(imagePath);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading promotions: " + ex.Message);
            }
        }


        private void SetupTimerForPromotions(PictureBox pictureBox)
        {
            if (promoImages.Count == 0)
                return;

            timerProm.Interval = 5000;
            timerProm.Tick += (s, e) => RotatePromotionImage(pictureBox);
            timerProm.Start();
        }

        private void RotatePromotionImage(PictureBox pictureBox)
        {
            if (promoImages.Count == 0)
                return;

            currentImageIndex = (currentImageIndex + 1) % promoImages.Count;
            pictureBox.ImageLocation = promoImages[currentImageIndex];
        }

        private void LoadPizzas()
        {
            try
            {
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                string query = @"
                SELECT 
                    p.Name AS PizzaName,
                    ct.Name AS CrustType,
                    st.Name AS SauceType,
                    ch.Name AS CheeseType,
                    p.BasePrice
                FROM Pizzas p
                INNER JOIN CrustTypes ct ON p.CrustTypeId = ct.CrustTypeId
                INNER JOIN SauceTypes st ON p.SauceTypeId = st.SauceTypeId
                INNER JOIN CheeseTypes ch ON p.CheeseTypeId = ch.CheeseTypeId";

                using var command = new SqlCommand(query, connection);
                using var reader = command.ExecuteReader();

                DataTable pizzaTable = new();
                pizzaTable.Load(reader);

                dgPizza.DataSource = pizzaTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading pizzas: " + ex.Message);
            }
        }



        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void btnFav_Click(object sender, EventArgs e)
        {

        }

        private void btnCust_Click(object sender, EventArgs e)
        {
            fCustomize customizeForm = new(); // Create instance of Pizza Customization form
            customizeForm.Show(); // Open Pizza Customization form
            this.Hide(); // Hide the Main Menu form
        }

        private void btnFav_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Ensure at least one row is selected
                if (dgPizza.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a pizza to add to favorites.");
                    return;
                }

                // Validate that the "PizzaId" column exists
                if (!dgPizza.Columns.Contains("PizzaId"))
                {
                    MessageBox.Show("The 'PizzaId' column is missing in the grid. Please reload the data.");
                    return;
                }

                // Retrieve the PizzaId value from the selected row
                var selectedRow = dgPizza.SelectedRows[0];
                if (selectedRow.Cells["PizzaId"].Value == null || selectedRow.Cells["PizzaId"].Value == DBNull.Value)
                {
                    MessageBox.Show("The selected pizza does not have a valid ID. Please check your data.");
                    return;
                }

                int pizzaId = Convert.ToInt32(selectedRow.Cells["PizzaId"].Value);

                // Execute the command to add the pizza to favorites
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                var addToFavoritesCommand = new AddToFavoritesCommand(connection, pizzaId: pizzaId);
                addToFavoritesCommand.Execute();

                MessageBox.Show("Pizza added to favorites successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding pizza to favorites: " + ex.Message);
            }
        }



        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (dgPizza.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a pizza to add.");
                return;
            }

            try
            {
                var selectedRow = dgPizza.SelectedRows[0];
                string pizzaName = selectedRow.Cells["PizzaName"].Value.ToString();

                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                string query = @"
                SELECT 
                    p.PizzaId, p.BasePrice
                FROM Pizzas p
                WHERE p.Name = @Name";

                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", pizzaName);
                using var reader = command.ExecuteReader();

                if (reader.Read())
                {
                    int pizzaId = (int)reader["PizzaId"];
                    decimal price = (decimal)reader["BasePrice"];

                    var addToCartCommand = new AddToCartCommand(UserSession.UserId, pizzaId, null, price, 1);
                    addToCartCommand.Execute();

                    MessageBox.Show("Pizza added to cart successfully!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding pizza to cart: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dgCart.SelectedRows.Count > 0)
            {
                int cartItemId = Convert.ToInt32(dgCart.SelectedRows[0].Cells["CartItemId"].Value);

                try
                {
                    using var connection = new SqlConnection(dbConn.ConnectionString);
                    connection.Open();

                    string query = "DELETE FROM ShoppingCart WHERE CartItemId = @CartItemId";

                    using var command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@CartItemId", cartItemId);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Item removed successfully.");
                        LoadShoppingCart(); // Refresh the cart data
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error removing item: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please select an item to remove.");
            }
        }

        private void btnPlace_Click(object sender, EventArgs e)
        {
            fPayment paymentForm = new(); // Create instance of Pizza Customization form
            paymentForm.Show(); // Open Pizza Customization form
            this.Hide(); // Hide the Main Menu form
        }

        private void LoadShoppingCart()
        {
            try
            {
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                string query = @"
                SELECT 
                    CartItemId, 
                    CASE 
                        WHEN PizzaId IS NOT NULL THEN 'Regular Pizza'
                        WHEN CustomPizzaId IS NOT NULL THEN 'Custom Pizza'
                    END AS PizzaType,
                    Quantity,
                    Price
                FROM ShoppingCart
                WHERE UserId = @UserId";

                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", UserSession.UserId);

                using var adapter = new SqlDataAdapter(command);
                DataTable cartTable = new();
                adapter.Fill(cartTable);

                dgCart.DataSource = cartTable;
                dgCart.Columns["CartItemId"].Visible = false; // Hide the ID column
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading shopping cart: " + ex.Message);
            }
        }

        private static int GetLoyaltyPoints()
        {
            using var connection = new SqlConnection(dbConn.ConnectionString);
            connection.Open();

            string query = "SELECT LoyaltyPoints FROM Users WHERE UserId = @UserId";
            using var command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@UserId", UserSession.UserId);

            return (int?)command.ExecuteScalar() ?? 0;
        }
        private void LoadUserLoyaltyPoints()
        {
            int points = GetLoyaltyPoints();
            lblLoyaltyPoints.Text = $"Loyalty Points: {points}";
        }

        private void tcHome_Click(object sender, EventArgs e)
        {

        }

        private void tcCart_Click(object sender, EventArgs e)
        {

        }

        private void tcMain_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (tcMain.SelectedTab == tcCart)
            {
                LoadShoppingCart();
            }
            if (tcMain.SelectedTab == tcFavorite)
            {
                LoadFavorites();
            }

            if (tcMain.SelectedTab == tcHistory)
            {
                LoadPastOrders(UserSession.UserId);
                LoadOngoingOrders(UserSession.UserId);
            }

        }

        private void btnBack_Click(object sender, EventArgs e)
        {

        }

        private void LoadFavorites()
        {
            try
            {
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                string query = @"
                SELECT 
                    f.FavoriteId, 
                    p.PizzaId, 
                    p.Name AS PizzaName, 
                    c.CustomPizzaId, 
                    c.Name AS CustomPizzaName,
                    c.BasePrice AS CustomPizzaPrice, 
                    p.BasePrice AS PizzaPrice,
                    ct.Name AS CrustName,
                    st.Name AS SauceName,
                    ch.Name AS CheeseName
                FROM Favorites f
                LEFT JOIN Pizzas p ON f.PizzaId = p.PizzaId
                LEFT JOIN CustomPizzas c ON f.CustomPizzaId = c.CustomPizzaId
                LEFT JOIN CrustTypes ct ON p.CrustTypeId = ct.CrustTypeId
                LEFT JOIN SauceTypes st ON p.SauceTypeId = st.SauceTypeId
                LEFT JOIN CheeseTypes ch ON p.CheeseTypeId = ch.CheeseTypeId
                WHERE f.UserId = @UserId";

                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", UserSession.UserId);

                using var adapter = new SqlDataAdapter(command);
                var favoritesTable = new DataTable();
                adapter.Fill(favoritesTable);

                dgFav.DataSource = favoritesTable;
                dgFav.Columns["FavoriteId"].Visible = false;
                dgFav.Columns["PizzaId"].Visible = false;
                dgFav.Columns["CustomPizzaId"].Visible = false;

                // Show custom or predefined pizza name
                dgFav.Columns.Add("Name", "Name");
                foreach (DataGridViewRow row in dgFav.Rows)
                {
                    if (row.DataBoundItem != null)
                    {
                        if (row.DataBoundItem is DataRowView drv)
                        {
                            DataRow dr = drv.Row;
                            if (dr["CustomPizzaName"] != DBNull.Value)
                            {
                                row.Cells["Name"].Value = dr["CustomPizzaName"];
                            }
                            else if (dr["PizzaName"] != DBNull.Value)
                            {
                                row.Cells["Name"].Value = dr["PizzaName"];
                            }
                        }
                    }
                }

                dgFav.Columns["CustomPizzaName"].Visible = false;
                dgFav.Columns["PizzaName"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading favorites: " + ex.Message);
            }
        }

        private void btnRem1_Click(object sender, EventArgs e)
        {
            if (dgFav.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an item to remove.");
                return;
            }

            var selectedRow = dgFav.SelectedRows[0];
            int favoriteId = Convert.ToInt32(selectedRow.Cells["FavoriteId"].Value);

            try
            {
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                string query = "DELETE FROM Favorites WHERE FavoriteId = @FavoriteId";
                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@FavoriteId", favoriteId);

                int rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Favorite removed successfully.");
                    LoadFavorites(); // Refresh the DataGridView
                }
                else
                {
                    MessageBox.Show("Failed to remove the favorite.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing favorite: " + ex.Message);
            }
        }

        private void btnCart1_Click(object sender, EventArgs e)
        {
            if (dgFav.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an item to add to the cart.");
                return;
            }

            var selectedRow = dgFav.SelectedRows[0];
            int? pizzaId = selectedRow.Cells["PizzaId"].Value as int?;
            int? customPizzaId = selectedRow.Cells["CustomPizzaId"].Value as int?;
            decimal price = pizzaId.HasValue
                ? Convert.ToDecimal(selectedRow.Cells["PizzaPrice"].Value)
                : Convert.ToDecimal(selectedRow.Cells["CustomPizzaPrice"].Value);

            var addToCartCommand = new AddToCartCommand(UserSession.UserId, pizzaId, customPizzaId, price, 1);
            try
            {
                addToCartCommand.Execute();
                MessageBox.Show("Item added to the cart successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding item to the cart: " + ex.Message);
            }
        }

        private void LoadPastOrders(int userId)
        {
            try
            {
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                string query = @"
                SELECT o.OrderId, 
                       od.PizzaId, 
                       od.CustomPizzaId, 
                       od.Quantity, 
                       od.Price, 
                       o.OrderDate
                FROM Orders o
                INNER JOIN OrderDetails od ON o.OrderId = od.OrderId
                WHERE o.UserId = @UserId AND 
                      ((o.IsDelivery = 1 AND o.DeliveryStatus = 'Delivered') OR 
                       (o.IsDelivery = 0 AND o.PickupStatus = 'Picked Up'))";

                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", userId);

                using var adapter = new SqlDataAdapter(command);
                var dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Bind data to DataGridView
                dgHis.DataSource = dataTable;

                // Optionally adjust column headers for user clarity
                dgHis.Columns["PizzaId"].HeaderText = "Pizza";
                dgHis.Columns["CustomPizzaId"].HeaderText = "Custom Pizza";
                dgHis.Columns["Quantity"].HeaderText = "Quantity";
                dgHis.Columns["Price"].HeaderText = "Price";
                dgHis.Columns["OrderDate"].HeaderText = "Order Date";
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Unexpected error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadOngoingOrders(int userId)
        {
            try
            {
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                string query = @"
                SELECT o.OrderId, 
                       od.PizzaId, 
                       od.CustomPizzaId, 
                       od.Quantity, 
                       od.Price, 
                       o.OrderDate, 
                       CASE 
                           WHEN o.IsDelivery = 1 THEN o.DeliveryStatus
                           WHEN o.IsDelivery = 0 THEN o.PickupStatus
                       END AS OrderStatus
                FROM Orders o
                INNER JOIN OrderDetails od ON o.OrderId = od.OrderId
                WHERE o.UserId = @UserId AND 
                      ((o.IsDelivery = 1 AND o.DeliveryStatus != 'Delivered') OR 
                       (o.IsDelivery = 0 AND o.PickupStatus != 'Picked Up'))";

                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", userId);

                using var adapter = new SqlDataAdapter(command);
                var dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Bind data to DataGridView
                dgOn.DataSource = dataTable;

                // Adjust column headers for user clarity
                dgOn.Columns["PizzaId"].HeaderText = "Pizza";
                dgOn.Columns["CustomPizzaId"].HeaderText = "Custom Pizza";
                dgOn.Columns["Quantity"].HeaderText = "Quantity";
                dgOn.Columns["Price"].HeaderText = "Price";
                dgOn.Columns["OrderDate"].HeaderText = "Order Date";
                dgOn.Columns["OrderStatus"].HeaderText = "Status";
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Unexpected error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void UpdateOrderStatusInDatabase(int orderId)
        {
            try
            {
                using var connection = new SqlConnection(dbConn.ConnectionString);
                connection.Open();

                // Retrieve the current status of the order
                string query = "SELECT DeliveryStatus FROM Orders WHERE OrderId = @OrderId";
                using var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@OrderId", orderId);

                var status = command.ExecuteScalar()?.ToString();

                // Initialize OrderContext with the current state
                OrderContext orderContext = status switch
                {
                    "Placed" => new OrderContext(new PlacedState()),
                    "Preparing" => new OrderContext(new PreparingState()),
                    "Out for Delivery" => new OrderContext(new OutForDeliveryState()),
                    "Delivered" => new OrderContext(new DeliveredState()),
                    _ => throw new Exception("Unknown order status.")
                };

                // Update the state
                orderContext.UpdateOrderStatus();
                string newStatus = orderContext.GetCurrentState();

                // Update the status in the database
                string updateQuery = "UPDATE Orders SET DeliveryStatus = @DeliveryStatus WHERE OrderId = @OrderId";
                using var updateCommand = new SqlCommand(updateQuery, connection);
                updateCommand.Parameters.AddWithValue("@DeliveryStatus", newStatus);
                updateCommand.Parameters.AddWithValue("@OrderId", orderId);

                updateCommand.ExecuteNonQuery();
                Console.WriteLine($"Order #{orderId} status updated to '{newStatus}'.");
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Unexpected error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshOngoingOrders(int userId)
        {
            LoadOngoingOrders(userId);

            foreach (DataGridViewRow row in dgOn.Rows)
            {
                if (row.Cells["OrderId"].Value != null)
                {
                    int orderId = Convert.ToInt32(row.Cells["OrderId"].Value);

                    // Update the status of the order
                    UpdateOrderStatusInDatabase(orderId);

                    // Reload the data to reflect the updated status
                    LoadOngoingOrders(userId);
                }
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            RefreshOngoingOrders(UserSession.UserId); // Refresh every interval
        }

        private System.Windows.Forms.Timer _timer;

        private void InitializeOrderTrackingTimer()
        {
            _timer = new System.Windows.Forms.Timer
            {
                Interval = 10000 // 5 seconds
            };
            _timer.Tick += Timer_Tick;
            _timer.Start();
        }

    }
}
