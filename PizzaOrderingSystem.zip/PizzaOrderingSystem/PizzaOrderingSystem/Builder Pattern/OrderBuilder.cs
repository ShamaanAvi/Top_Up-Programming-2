﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PizzaOrderingSystem
{
    public class OrderBuilder(SqlConnection connection)
    {
        private readonly SqlConnection _connection = connection ?? throw new ArgumentNullException(nameof(connection), "Connection cannot be null.");
        private SqlTransaction _transaction;
        private int _userId;
        private bool _isDelivery;
        private decimal _totalPrice;
        private string _deliveryAddress;
        private int _orderId;

        public OrderBuilder StartTransaction()
        {
            _transaction = _connection.BeginTransaction();
            return this;
        }
        public TResult ExecuteQuery<TResult>(string query, Func<SqlCommand, TResult> execute, Action<SqlCommand> configureParameters = null)
        {
            using var command = new SqlCommand(query, _connection, _transaction);
            configureParameters?.Invoke(command);
            return execute(command);
        }

        public OrderBuilder SetUserId(int userId)
        {
            _userId = userId;
            return this;
        }

        public OrderBuilder SetDeliveryOption(bool isDelivery)
        {
            _isDelivery = isDelivery;
            return this;
        }

        public OrderBuilder SetDeliveryAddress(string deliveryAddress)
        {
            if (_isDelivery && string.IsNullOrWhiteSpace(deliveryAddress))
                throw new ArgumentException("Delivery address cannot be empty for delivery orders.");

            _deliveryAddress = deliveryAddress;
            return this;
        }

        public OrderBuilder CalculateTotalPrice()
        {
            const string totalPriceQuery = "SELECT SUM(Price * Quantity) FROM ShoppingCart WHERE UserId = @UserId";
            using var totalPriceCommand = new SqlCommand(totalPriceQuery, _connection, _transaction);
            totalPriceCommand.Parameters.AddWithValue("@UserId", _userId);
            _totalPrice = (decimal?)totalPriceCommand.ExecuteScalar() ?? 0;
            return this;
        }

        public OrderBuilder InsertOrder()
        {
            const string orderQuery = @"
            INSERT INTO Orders (UserId, OrderDate, DeliveryStatus, PickupStatus, IsDelivery, DeliveryAddress, TotalPrice)
            OUTPUT INSERTED.OrderId
            VALUES (@UserId, GETDATE(), 
                    CASE WHEN @IsDelivery = 1 THEN 'Placed' ELSE NULL END,
                    CASE WHEN @IsDelivery = 0 THEN 'Placed' ELSE NULL END,
                    @IsDelivery, @DeliveryAddress, @TotalPrice)";

            using var orderCommand = new SqlCommand(orderQuery, _connection, _transaction);
            orderCommand.Parameters.AddWithValue("@UserId", _userId);
            orderCommand.Parameters.AddWithValue("@IsDelivery", _isDelivery);
            orderCommand.Parameters.AddWithValue("@DeliveryAddress", (object)_deliveryAddress ?? DBNull.Value);
            orderCommand.Parameters.AddWithValue("@TotalPrice", _totalPrice);

            _orderId = (int)orderCommand.ExecuteScalar();
            return this;
        }

        public OrderBuilder InsertOrderDetails()
        {
            const string orderDetailsQuery = @"
            INSERT INTO OrderDetails (OrderId, PizzaId, CustomPizzaId, Quantity, Price)
            SELECT @OrderId, PizzaId, CustomPizzaId, Quantity, Price
            FROM ShoppingCart
            WHERE UserId = @UserId";

            using var orderDetailsCommand = new SqlCommand(orderDetailsQuery, _connection, _transaction);
            orderDetailsCommand.Parameters.AddWithValue("@OrderId", _orderId);
            orderDetailsCommand.Parameters.AddWithValue("@UserId", _userId);
            orderDetailsCommand.ExecuteNonQuery();
            return this;
        }

        public OrderBuilder ClearShoppingCart()
        {
            const string clearCartQuery = "DELETE FROM ShoppingCart WHERE UserId = @UserId";

            using var clearCartCommand = new SqlCommand(clearCartQuery, _connection, _transaction);
            clearCartCommand.Parameters.AddWithValue("@UserId", _userId);
            clearCartCommand.ExecuteNonQuery();
            return this;
        }

        public OrderBuilder UpdateLoyaltyPoints()
        {
            // Calculate points based on the total price (e.g., 1 point per $10)
            int pointsEarned = (int)Math.Floor(_totalPrice / 10);

            // Update the user's loyalty points
            const string loyaltyPointsQuery = @"
        UPDATE Users
        SET LoyaltyPoints = LoyaltyPoints + @PointsEarned
        WHERE UserId = @UserId";

            using var loyaltyCommand = new SqlCommand(loyaltyPointsQuery, _connection, _transaction);
            loyaltyCommand.Parameters.AddWithValue("@PointsEarned", pointsEarned);
            loyaltyCommand.Parameters.AddWithValue("@UserId", _userId);

            loyaltyCommand.ExecuteNonQuery();
            return this;
        }

        public OrderBuilder RedeemLoyaltyPoints(int pointsToRedeem)
        {
            const string redeemQuery = @"
        UPDATE Users
        SET LoyaltyPoints = LoyaltyPoints - @Points
        WHERE UserId = @UserId AND LoyaltyPoints >= @Points";

            using var redeemCommand = new SqlCommand(redeemQuery, _connection, _transaction);
            redeemCommand.Parameters.AddWithValue("@Points", pointsToRedeem);
            redeemCommand.Parameters.AddWithValue("@UserId", _userId);

            int rowsAffected = redeemCommand.ExecuteNonQuery();
            if (rowsAffected == 0)
                throw new Exception("Insufficient loyalty points.");

            // Deduct discount from total price
            _totalPrice -= pointsToRedeem; // Assume 1 point = $1 discount
            return this;
        }

        public void CommitTransaction()
        {
            _transaction.Commit();
        }

        public void RollbackTransaction()
        {
            _transaction.Rollback();
        }

        public int GetOrderId() => _orderId;

        public decimal TotalPrice => _totalPrice;
    }


}
