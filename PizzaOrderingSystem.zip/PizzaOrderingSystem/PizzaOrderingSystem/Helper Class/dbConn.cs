﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem
{
    public static class dbConn
    {
        // Connection string 
        public static string ConnectionString
        {
            get
            {
                return @"Data Source=DESKTOP-DUFGFCU\SQLEXPRESS;Initial Catalog=PizzaOrderingSystemDB;Persist Security Info=True;User ID=sa;Password=Shaamil123;Encrypt=True;Trust Server Certificate=True";
            }
        }
    }
}
