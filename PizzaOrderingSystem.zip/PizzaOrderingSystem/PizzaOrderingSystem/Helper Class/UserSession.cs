﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem
{
    public static class UserSession
    {
        public static int UserId { get; set; } // Store logged-in user's ID
        public static string? Username { get; set; }
        public static string? Email { get; set; }

    }
}
