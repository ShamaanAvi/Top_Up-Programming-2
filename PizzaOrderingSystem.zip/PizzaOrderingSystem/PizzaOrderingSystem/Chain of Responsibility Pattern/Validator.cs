﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Chain_of_Responsibility_Pattern
{
    public abstract class Validator
    {
        private Validator _next;

        public Validator SetNext(Validator next)
        {
            _next = next;
            return _next;
        }

        public void Validate(ValidationContext context)
        {
            PerformValidation(context);
            _next?.Validate(context);
        }

        protected abstract void PerformValidation(ValidationContext context);
    }

}
