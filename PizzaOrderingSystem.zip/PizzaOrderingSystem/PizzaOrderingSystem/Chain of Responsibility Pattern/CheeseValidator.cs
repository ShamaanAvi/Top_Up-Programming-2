﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Chain_of_Responsibility_Pattern
{
    public class CheeseValidator : Validator
    {
        protected override void PerformValidation(ValidationContext context)
        {
            if (context.Cheese == null)
                throw new Exception("Cheese type is required.");
        }
    }

}
