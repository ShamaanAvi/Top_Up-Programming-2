﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Chain_of_Responsibility_Pattern
{
    public class ToppingValidator : Validator
    {
        protected override void PerformValidation(ValidationContext context)
        {
            if (context.Topping1 == context.Topping2 && context.Topping1 != null)
                throw new Exception("Toppings must be unique.");
        }
    }
}
