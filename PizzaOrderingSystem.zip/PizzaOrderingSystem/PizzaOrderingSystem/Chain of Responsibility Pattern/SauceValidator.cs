﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Chain_of_Responsibility_Pattern
{
    public class SauceValidator : Validator
    {
        protected override void PerformValidation(ValidationContext context)
        {
            if (context.Sauce == null)
                throw new Exception("Sauce type is required.");
        }
    }

}
