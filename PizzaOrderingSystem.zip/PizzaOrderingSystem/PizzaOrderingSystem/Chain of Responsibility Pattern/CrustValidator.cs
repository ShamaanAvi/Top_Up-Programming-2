﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Chain_of_Responsibility_Pattern
{
    public class CrustValidator : Validator
    {
        protected override void PerformValidation(ValidationContext context)
        {
            if (context.Crust == null)
                throw new Exception("Crust type is required.");
        }
    }

}
