﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Chain_of_Responsibility_Pattern
{
    public class ValidationContext
    {
        public ComboBoxItem Crust { get; set; }
        public ComboBoxItem Sauce { get; set; }
        public ComboBoxItem Cheese { get; set; }
        public ComboBoxItem Topping1 { get; set; }
        public ComboBoxItem Topping2 { get; set; }
    }

}
