﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PizzaOrderingSystem.Strategy_Pattern
{
    public class LoyaltyPointsPayment(int userId) : IPaymentStrategy
    {
        private readonly int _userId = userId;

        public void ProcessPayment(OrderBuilder orderBuilder)
        {
            // Fetch available loyalty points
            const string query = "SELECT LoyaltyPoints FROM Users WHERE UserId = @UserId";
            int availablePoints = orderBuilder.ExecuteQuery(
                query,
                command =>
                {
                    return (int)command.ExecuteScalar();
                },
                command =>
                {
                    command.Parameters.AddWithValue("@UserId", _userId);
                });

            // Redeem loyalty points
            int pointsToRedeem = availablePoints;
            orderBuilder.RedeemLoyaltyPoints(pointsToRedeem);
        }
    }


}
