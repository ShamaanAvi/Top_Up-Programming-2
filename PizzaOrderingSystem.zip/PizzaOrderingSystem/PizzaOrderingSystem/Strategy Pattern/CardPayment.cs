﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace PizzaOrderingSystem.Strategy_Pattern
{
    public class CardPayment : IPaymentStrategy
    {
        public void ProcessPayment(OrderBuilder orderBuilder)
        {
            // No additional processing needed for Card

        }
    }

}
