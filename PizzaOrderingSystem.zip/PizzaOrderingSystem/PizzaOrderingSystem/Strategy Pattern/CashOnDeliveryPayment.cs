﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaOrderingSystem.Strategy_Pattern
{
    public class CashOnDeliveryPayment : IPaymentStrategy
    {
        public void ProcessPayment(OrderBuilder orderBuilder)
        {
            // No additional processing needed for Cash on Delivery
        }
    }

}
